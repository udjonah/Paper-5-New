
10. sens.py       sensitivity analysis on the 2,262 firm-focused records
11. tccm.py       dictionary-based TCCM coding of the research fronts (dictionaries inside)
