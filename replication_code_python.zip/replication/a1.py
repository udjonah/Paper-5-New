exec(open('load.py').read())
import json
out={}
yrs=np.arange(1989,2026)
ann=M.groupby(['Year','community']).size().unstack(fill_value=0).reindex(yrs,fill_value=0)
ann['total']=ann.sum(1)
ann.to_csv('annual.csv')
y=np.log1p(ann.total.values.astype(float)); T=len(y)
def ssr(i,j):  # segment [i,j) with intercept+trend
    t=np.arange(i,j); X=np.c_[np.ones(j-i),t]; b=np.linalg.lstsq(X,y[i:j],rcond=None)[0]; return ((y[i:j]-X@b)**2).sum()
h=4
S={(i,j):ssr(i,j) for i in range(T) for j in range(i+h,T+1)}
def best(m):
    # DP: min SSR with m breaks
    from functools import lru_cache
    @lru_cache(None)
    def f(k,end):
        if k==0: return (S[(0,end)],()) if (0,end) in S else (np.inf,())
        bestv=(np.inf,())
        for b in range(h*k,end-h+1):
            v,bs=f(k-1,b)
            if (b,end) in S and v+S[(b,end)]<bestv[0]: bestv=(v+S[(b,end)],bs+(b,))
        return bestv
    return f(m,T)
res=[]
for m in range(0,6):
    v,bs=best(m); k=2*(m+1)+m
    bic=T*np.log(v/T)+k*np.log(T); lwz=T*np.log(v/T)+k*0.299*np.log(T)**2.1
    res.append((m,v,bic,lwz,[int(yrs[b]) for b in bs]))
for r in res: print(r)
json.dump(res,open('breaks.json','w'))
print(ann.tail(12)); print(ann.sum())
