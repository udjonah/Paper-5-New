import numpy as np
from functools import lru_cache
def bai_perron(y,h=4,mmax=5,trend=True):
    y=np.asarray(y,float);T=len(y)
    def ssr(i,j):
        t=np.arange(i,j); X=np.c_[np.ones(j-i),t] if trend else np.ones((j-i,1)); b=np.linalg.lstsq(X,y[i:j],rcond=None)[0]; return ((y[i:j]-X@b)**2).sum()
    S={(i,j):ssr(i,j) for i in range(T) for j in range(i+h,T+1)}
    @lru_cache(None)
    def f(k,end):
        if k==0: return (S.get((0,end),np.inf),())
        bv=(np.inf,())
        for b in range(h*k,end-h+1):
            v,bs=f(k-1,b)
            if (b,end) in S and v+S[(b,end)]<bv[0]: bv=(v+S[(b,end)],bs+(b,))
        return bv
    p=2 if trend else 1; out=[]
    for m in range(mmax+1):
        v,bs=f(m,T); k=p*(m+1)+m
        out.append(dict(m=m,ssr=v,bic=T*np.log(v/T)+k*np.log(T),breaks=list(bs)))
    best=min(out,key=lambda d:d['bic'])
    return best,out
def ci_breaks(y,breaks,h=4,trend=True,B=999,seed=1):
    # residual bootstrap of break locations (fixed m)
    y=np.asarray(y,float);T=len(y);rng=np.random.default_rng(seed)
    m=len(breaks)
    if m==0: return []
    segs=[0]+list(breaks)+[T];fit=np.zeros(T)
    for a,b in zip(segs[:-1],segs[1:]):
        t=np.arange(a,b);X=np.c_[np.ones(b-a),t] if trend else np.ones((b-a,1))
        fit[a:b]=X@np.linalg.lstsq(X,y[a:b],rcond=None)[0]
    res=y-fit;draws=[]
    for _ in range(B):
        yb=fit+rng.choice(res,T,replace=True)
        _,o=bai_perron(yb,h,m,trend);draws.append(o[m]['breaks'])
    d=np.array(draws)
    return [(int(np.percentile(d[:,i],2.5)),int(np.percentile(d[:,i],97.5))) for i in range(m)]
