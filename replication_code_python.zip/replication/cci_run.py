exec(open('load.py').read())
from bp import *
from collections import Counter
cA=Counter(k for r in M[M.community=='A'].refs for k in r)
cB=Counter(k for r in M[M.community=='B'].refs for k in r)
out={}
for N in [50,100,200]:
    coreA={k for k,_ in cA.most_common(N)}; coreB={k for k,_ in cB.most_common(N)}
    M[f'inB{N}']=M.refs.apply(lambda r: np.mean([k in coreB for k in r]) if r else np.nan)
    M[f'inA{N}']=M.refs.apply(lambda r: np.mean([k in coreA for k in r]) if r else np.nan)
    print(N,'core overlap',len(coreA&coreB))
N=100
coreA={k for k,_ in cA.most_common(N)}; coreB={k for k,_ in cB.most_common(N)}
print('shared core:', sorted(coreA&coreB, key=lambda k:-(cA[k]+cB[k]))[:20])
print('top B core:', [ (k,cB[k]) for k,_ in cB.most_common(12)])
g=M.groupby('Year')
cci=pd.DataFrame({'A_to_B':g.apply(lambda d:d.loc[d.community=='A','inB100'].mean()),
                  'B_to_A':g.apply(lambda d:d.loc[d.community=='B','inA100'].mean()),
                  'nA':g.apply(lambda d:(d.community=='A').sum()),'nB':g.apply(lambda d:(d.community=='B').sum()),
                  'share_AB':g.apply(lambda d:(d.community=='A&B').mean())})
cci.to_csv('cci.csv'); print(cci.loc[2000:].round(3).to_string())
for col in ['A_to_B','B_to_A']:
    s=cci.loc[2005:2025,col].fillna(0)
    best,o=bai_perron(s.values,trend=False)
    print(col,[(d['m'],round(d['bic'],1),[int(s.index[b]) for b in d['breaks']]) for d in o[:4]])
# period means
for a,b in [(1989,2011),(2012,2016),(2017,2020),(2021,2025)]:
    d=M[(M.Year>=a)&(M.Year<=b)]
    print(a,b,'A->B',round(d.loc[d.community=='A','inB100'].mean()*100,2),'B->A',round(d.loc[d.community=='B','inA100'].mean()*100,2),
      'AB->A',round(d.loc[d.community=='A&B','inA100'].mean()*100,2),'AB->B',round(d.loc[d.community=='A&B','inB100'].mean()*100,2))
for N in [50,200]:
    d=M[M.Year>=2021]; d0=M[(M.Year>=2012)&(M.Year<=2016)]
    print(N,'2012-16 A->B',round(d0.loc[d0.community=='A',f'inB{N}'].mean()*100,2),'B->A',round(d0.loc[d0.community=='B',f'inA{N}'].mean()*100,2),
          '2021-25 A->B',round(d.loc[d.community=='A',f'inB{N}'].mean()*100,2),'B->A',round(d.loc[d.community=='B',f'inA{N}'].mean()*100,2))
M[['EID','Year','community','inA100','inB100']].to_csv('cci_docs.csv',index=False)
