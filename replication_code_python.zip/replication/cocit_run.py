exec(open('load.py').read())
from net import *
CUTS=[1989,2012,2017,2021,2026]
M['phase']=pd.cut(M.Year,CUTS,right=False,labels=[1,2,3,4]).astype(int)
import json
res={}
for ph in [1,2,3,4]:
    d=M[M.phase==ph]
    G,mem,Q,cnt=cocit(d.refs.tolist(),top=60)
    print(f'=== Phase {ph} docs={len(d)} nodes={G.number_of_nodes()} Q={Q:.3f}')
    for c in sorted(set(mem.values())):
        ms=sorted([k for k in mem if mem[k]==c],key=lambda k:-cnt[k])
        print(' C',c,len(ms),'|', '; '.join(f"{k.split('|')[0]} {k.split('|')[1]} ({k.split('|')[2][:22]}) {cnt[k]}" for k in ms[:8]))
    res[ph]={'Q':Q,'mem':mem,'cnt':{k:cnt[k] for k in mem}}
json.dump({p:{'Q':v['Q'],'mem':v['mem'],'cnt':v['cnt']} for p,v in res.items()},open('cocit.json','w'))
