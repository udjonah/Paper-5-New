exec(open('load.py').read())
import networkx as nx, itertools
from collections import Counter, defaultdict
d=M[(M.Year>=2021)].copy()
d=d[d.refs.str.len()>=10]
inv=defaultdict(list)
for i,r in zip(d.index,d.refs):
    for k in r: inv[k].append(i)
co=Counter()
for k,ds in inv.items():
    if len(ds)>200: continue  # skip ubiquitous refs to keep tractable? record
    for a,b in itertools.combinations(sorted(ds),2): co[(a,b)]+=1
nr=d.refs.str.len().to_dict()
G=nx.Graph()
for (a,b),c in co.items():
    if c>=2: G.add_edge(a,b,weight=c/np.sqrt(nr[a]*nr[b]))
print('docs',len(d),'nodes',G.number_of_nodes(),'edges',G.number_of_edges())
comms=nx.community.louvain_communities(G,weight='weight',seed=7)
comms=sorted(comms,key=len,reverse=True)
Q=nx.community.modularity(G,comms,weight='weight'); print('Q',round(Q,3))
allkw=Counter(k.strip().lower() for s in d['Author Keywords'].dropna() for k in s.split(';'))
tot=len(d)
rows=[]
for ci,c in enumerate(comms):
    if len(c)<30: continue
    sub=M.loc[list(c)]
    kw=Counter(k.strip().lower() for s in sub['Author Keywords'].dropna() for k in s.split(';'))
    lift=sorted([k for k in kw if kw[k]>=5],key=lambda k:-(kw[k]/len(c))/(allkw[k]/tot)*np.log1p(kw[k]))[:10]
    top=sub.sort_values('TC',ascending=False).head(4)
    print(f'\n== cluster {ci} n={len(c)} meanyear={sub.Year.mean():.1f} comm={sub.community.value_counts(normalize=True).round(2).to_dict()} TC/doc={sub.TC.mean():.1f}')
    print('  kw:', ', '.join(lift))
    print('  freq:', ', '.join(k for k,_ in kw.most_common(8)))
    for _,r in top.iterrows(): print('   ',r.Year,r.Authors[:30],'|',r.Title[:100],r.TC)
    rows.append(dict(cluster=ci,n=len(c),meanyear=sub.Year.mean(),pA=(sub.community=='A').mean(),pB=(sub.community=='B').mean(),pAB=(sub.community=='A&B').mean(),tc=sub.TC.mean(),kw='; '.join(lift[:6])))
pd.DataFrame(rows).to_csv('coupling.csv',index=False)
import pickle; pickle.dump({n:i for i,c in enumerate(comms) for n in c},open('coup_mem.pkl','wb'))
