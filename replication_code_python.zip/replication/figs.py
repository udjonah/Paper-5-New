import pandas as pd,numpy as np,matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt, pickle
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
ann=pd.read_csv('annual.csv',index_col=0)
C={'A':'#3b6ea5','B':'#d1853a','A&B':'#5a9e6f'}
fig,ax=plt.subplots(figsize=(8,4.2))
x=ann.index
ax.bar(x,ann.A,color=C['A'],label='Set A only: SME finance')
ax.bar(x,ann['A&B'],bottom=ann.A,color=C['A&B'],label='Both sets: bridging')
ax.bar(x,ann.B,bottom=ann.A+ann['A&B'],color=C['B'],label='Set B only: enterprise financial inclusion')
for b in [2012,2017,2021]: ax.axvline(b-0.5,color='#555',ls='--',lw=0.9)
for (a,b,l) in [(1989,2011,'Phase 1\n1989–2011'),(2012,2016,'Phase 2\n2012–16'),(2017,2020,'Phase 3\n2017–20'),(2021,2025,'Phase 4\n2021–25')]:
    ax.text((a+b)/2 if a>1989 else 2002,560,l,ha='center',va='top',fontsize=8.5,color='#333')
ax.set_ylabel('Documents per year'); ax.set_xlim(1988.3,2025.7); ax.set_ylim(0,620)
ax.legend(frameon=False,loc='center left',bbox_to_anchor=(0.0,0.55),fontsize=8.5)
ax.set_title('Figure 2. Annual output by community, 1989–2025 (n = 3,109)',loc='left',fontsize=11)
fig.text(0.01,0.005,'Dashed lines: structural breaks in Set B\'s share of annual output (Bai–Perron, BIC). Source: Scopus, 19 Nov 2026.',fontsize=7.5,color='#555')
fig.tight_layout(rect=(0,0.03,1,1)); fig.savefig('fig2_annual.png',dpi=220)
c=pd.read_csv('cci_excl.csv',index_col=0).loc[2005:2025]
fig,ax=plt.subplots(figsize=(8,4))
ax.plot(c.index,100*c.A_to_B,marker='o',ms=3,color=C['A'],label='SME finance citing the inclusion core')
ax.plot(c.index,100*c.B_to_A,marker='o',ms=3,color=C['B'],label='Inclusion research citing the SME finance core')
ax.plot(c.index,100*c.share_AB,marker='s',ms=3,color=C['A&B'],label='Bridging papers, share of annual output')
ax.set_ylabel('Per cent'); ax.set_xticks(range(2005,2026,2))
ax.legend(frameon=False,fontsize=8.5,loc='upper left')
ax.set_title('Figure 3. Co-location rose; cross-citation did not',loc='left',fontsize=11)
fig.text(0.01,0.005,'Cross-citation = mean share of a paper\'s references in the other community\'s exclusive top-100 core. Source: Scopus, 19 Nov 2026.',fontsize=7.5,color='#555')
fig.tight_layout(rect=(0,0.03,1,1)); fig.savefig('fig3_cci.png',dpi=220)
th=pickle.load(open('themes.pkl','rb'))[4]
fig,ax=plt.subplots(figsize=(7.5,5.5))
cm,dm=th.centrality.median(),th.density.median()
ax.axvline(cm,color='#999',lw=0.8); ax.axhline(dm,color='#999',lw=0.8)
s=th.freq/th.freq.max()*2200+80
ax.scatter(th.centrality,th.density,s=s,alpha=0.35,color=C['A'],edgecolor=C['A'])
for _,r in th.iterrows():
    ax.annotate('\n'.join(r.words[:2]),(r.centrality,r.density),ha='center',va='center',fontsize=7.5)
xl=ax.get_xlim(); yl=ax.get_ylim(); yl=(yl[0]-0.45,yl[1]+0.25); xl=(xl[0]-0.6,xl[1]+0.6); ax.set_xlim(xl); ax.set_ylim(yl)
for tx,ty,l,ha,va in [(xl[1],yl[1],'Motor themes','right','top'),(xl[0],yl[1],'Niche themes','left','top'),(xl[0],yl[0],'Emerging or declining','left','bottom'),(xl[1],yl[0],'Basic themes','right','bottom')]:
    ax.text(tx,ty,l,ha=ha,va=va,fontsize=9,color='#777',style='italic')
ax.set_xlabel('Centrality (relevance to the field)'); ax.set_ylabel('Density (internal development)')
ax.set_title('Figure 4. Thematic map, 2021–2025',loc='left',fontsize=11)
fig.text(0.01,0.005,'Bubble size = keyword occurrences. Author keywords, Louvain clustering, Callon centrality and density. Source: Scopus.',fontsize=7.5,color='#555')
fig.tight_layout(rect=(0,0.03,1,1)); fig.savefig('fig4_thematic.png',dpi=220)
