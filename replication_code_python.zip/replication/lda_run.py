exec(open('load.py').read())
from sklearn.feature_extraction.text import CountVectorizer, ENGLISH_STOP_WORDS
from sklearn.decomposition import LatentDirichletAllocation
from sklearn.metrics import normalized_mutual_info_score as nmi
import pickle
ab=M.Abstract.fillna('')
ab=ab.str.replace(r'©.*$','',regex=True).str.replace(r'\(C\).*$','',regex=True)
ok=ab.str.len()>200
D=M[ok].copy(); txt=ab[ok]
stop=list(ENGLISH_STOP_WORDS)+'study paper results research findings using use used based analysis data evidence effect effects impact role article authors elsevier rights reserved ltd licensee emerald publishing limited springer taylor francis purpose design methodology approach originality value implications practical paper also however may significant significantly show shows find found suggest'.split()
cv=CountVectorizer(stop_words=stop,min_df=10,max_df=0.4,ngram_range=(1,2),token_pattern=r'(?u)\b[a-z][a-z\-]{2,}\b')
X=cv.fit_transform(txt.str.lower()); V=np.array(cv.get_feature_names_out())
print('docs',X.shape)
Xb=(X>0).astype(int).tocsc()
df=np.asarray(Xb.sum(0)).ravel()
def umass(comp,n=10):
    s=[]
    for t in comp:
        idx=np.argsort(t)[::-1][:n]; sc=0
        for i in range(1,n):
            for j in range(i):
                co=Xb[:,idx[i]].multiply(Xb[:,idx[j]]).sum()
                sc+=np.log((co+1)/df[idx[j]])
        s.append(sc/(n*(n-1)/2))
    return np.mean(s)
def excl(comp,n=10):
    p=comp/comp.sum(1,keepdims=True); share=p/p.sum(0,keepdims=True)
    return np.mean([share[k,np.argsort(p[k])[::-1][:n]].mean() for k in range(len(p))])
res={}
for K in [6,8,10,12,14,16]:
    lda=LatentDirichletAllocation(n_components=K,learning_method='batch',max_iter=40,random_state=1,doc_topic_prior=0.1,topic_word_prior=0.01)
    th=lda.fit_transform(X)
    res[K]=(umass(lda.components_),excl(lda.components_),lda,th)
    print(K,'umass',round(res[K][0],3),'excl',round(res[K][1],3))
pickle.dump({K:(r[0],r[1],r[2].components_,r[3]) for K,r in res.items()},open('lda.pkl','wb'))
pickle.dump((D.EID.values,V),open('lda_meta.pkl','wb'))
