import pandas as pd, numpy as np, re, unicodedata
U='/mnt/user-data/uploads/'
A=pd.read_csv(U+'export_02139bb1-87ea-4079-a29e-052980c0e1fe_2026-11-19T190154_877999359.csv')
B=pd.read_csv(U+'export_ba5f34f5-c78b-4748-bab8-b0a9bff8636e_2026-11-19T190328_120043417.csv')
raw={'A':len(A),'B':len(B)}
sa,sb=set(A.EID),set(B.EID)
M=pd.concat([A,B]).drop_duplicates('EID').reset_index(drop=True)
M['community']=np.where(M.EID.isin(sa)&M.EID.isin(sb),'A&B',np.where(M.EID.isin(sa),'A','B'))
n_union=len(M)
M=M[M.Year<=2025].reset_index(drop=True)
def norm(s):
    s=unicodedata.normalize('NFKD',str(s)).encode('ascii','ignore').decode().lower()
    return re.sub(r'[^a-z0-9 ]','',s)
AUTH=re.compile(r"^\s*([^,]+?\s(?:[A-Z]\.)(?:[- ]?[A-Z]\.)*)\s*$")
def split_refs(s):
    return [x.strip() for x in re.split(r'(?<=\(\d{4}\));\s+', s) if x.strip()]
def parse_ref(r):
    yr=re.search(r'\((\d{4})\)\s*$',r) or re.search(r'\((\d{4})\)',r)
    if not yr: return None
    r=r.replace('; ',', ')
    parts=[p.strip() for p in r.split(', ')]
    i=0; auths=[]
    while i<len(parts) and AUTH.match(parts[i]): auths.append(parts[i]); i+=1
    if not auths or i>=len(parts): return None
    sur=norm(auths[0].rsplit(' ',1)[0]).replace(' ','')
    title=norm(parts[i])[:30].strip()
    if len(title)<8: return None
    return f"{sur}|{yr.group(1)}|{title}"
def doc_key(row):
    a=str(row.Authors).split(';')[0].strip()
    sur=norm(a.rsplit(' ',1)[0]).replace(' ','') if ' ' in a else norm(a)
    return f"{sur}|{int(row.Year)}|{norm(row.Title)[:30].strip()}"
M['dkey']=M.apply(doc_key,axis=1)
M['refs']=M.References.fillna('').apply(lambda s: list(dict.fromkeys(k for k in (parse_ref(r) for r in split_refs(s)) if k)))
M['nref_raw']=M.References.fillna('').apply(lambda s: len(split_refs(s)))
M['TC']=M['Cited by'].fillna(0).astype(int)
