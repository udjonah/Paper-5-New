exec(open('load.py').read())
import networkx as nx
key2i={}
for i,k in enumerate(M.dkey): key2i.setdefault(k,i)
# looser key: surname|year|first 20 chars
def loose(k):
    s,y,t=k.split('|'); return f"{s}|{y}|{t[:20]}"
l2i={}
for i,k in enumerate(M.dkey): l2i.setdefault(loose(k),i)
E=set()
for i,refs in enumerate(M.refs):
    for r in refs:
        j=key2i.get(r, l2i.get(loose(r)))
        if j is not None and j!=i: E.add((j,i))   # cited -> citing
print('local citation edges',len(E))
G=nx.DiGraph(); G.add_nodes_from(range(len(M))); G.add_edges_from(E)
yr=M.Year.values
bad=[(u,v) for u,v in G.edges if yr[u]>yr[v]]; G.remove_edges_from(bad)
while not nx.is_directed_acyclic_graph(G):
    cyc=nx.find_cycle(G); G.remove_edge(*cyc[-1])
M['LCS']=[G.out_degree(i) for i in range(len(M))]
print('docs with LCS>0',(M.LCS>0).sum())
H=G.subgraph([n for n in G if G.degree(n)>0]).copy()
order=list(nx.topological_sort(H))
nm={};npl={}
for v in order:
    pr=list(H.predecessors(v)); nm[v]=sum(nm[p] for p in pr) if pr else 1
for v in reversed(order):
    sc=list(H.successors(v)); npl[v]=sum(npl[s] for s in sc) if sc else 1
for u,v in H.edges: H[u][v]['spc']=nm[u]*npl[v]
best={};nxt={}
for v in reversed(order):
    outs=[(H[v][s]['spc']+best[s],s) for s in H.successors(v)]
    if outs: best[v],nxt[v]=max(outs)
    else: best[v]=0
srcs=[v for v in H if H.in_degree(v)==0 and H.out_degree(v)>0]
v=max(srcs,key=lambda s:best[s]); path=[v]
while v in nxt: v=nxt[v]; path.append(v)
print('MAIN PATH')
for p in path: print(M.Year[p], M.community[p], M.Authors[p][:40], '|', M.Title[p][:90], '| LCS',M.LCS[p])
# key-route: top-SPC edge, extend both ways
u0,v0=max(H.edges,key=lambda e:H[e[0]][e[1]]['spc'])
fw=[v0]; v=v0
while v in nxt: v=nxt[v]; fw.append(v)
bw=[u0]; u=u0
while True:
    pr=list(H.predecessors(u))
    if not pr: break
    u=max(pr,key=lambda p:H[p][u]['spc']); bw.append(u)
kr=bw[::-1]+fw
print('KEY ROUTE')
for p in kr: print(M.Year[p], M.community[p], M.Authors[p][:40], '|', M.Title[p][:90])
# bridges: betweenness on undirected local citation graph
U=H.to_undirected()
bet=nx.betweenness_centrality(U,k=min(800,len(U)),seed=1)
top=sorted(bet,key=lambda n:-bet[n])[:12]
print('BRIDGES')
for p in top: print(round(bet[p],4), M.Year[p], M.community[p], M.Authors[p][:35],'|',M.Title[p][:90])
# cross-community local citation flows
flow=pd.Series([ (M.community[u],M.community[v]) for u,v in H.edges]).value_counts()
print(flow)
pd.DataFrame({'path':path}).to_csv('mainpath_idx.csv',index=False)
M[['EID','LCS']].to_csv('lcs.csv',index=False)
import pickle; pickle.dump({'path':path,'kr':kr,'top':top,'bet':{p:bet[p] for p in top},'flow':flow.to_dict()},open('mp.pkl','wb'))
