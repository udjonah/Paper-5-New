import numpy as np, pandas as pd, networkx as nx, itertools
from collections import Counter
from sklearn.metrics import normalized_mutual_info_score as nmi
def cocit(docs_refs, top=60, norm='association', algo='louvain', seed=7):
    cnt=Counter(k for r in docs_refs for k in r)
    keep=[k for k,_ in cnt.most_common(top)]; ks=set(keep)
    co=Counter()
    for r in docs_refs:
        rr=sorted(set(r)&ks)
        for a,b in itertools.combinations(rr,2): co[(a,b)]+=1
    G=nx.Graph()
    for k in keep: G.add_node(k,n=cnt[k])
    for (a,b),c in co.items():
        if norm=='association': w=c/(cnt[a]*cnt[b])
        elif norm=='salton': w=c/np.sqrt(cnt[a]*cnt[b])
        else: w=c
        G.add_edge(a,b,weight=w,raw=c)
    G.remove_nodes_from([n for n in list(G) if G.degree(n)==0])
    if algo=='louvain': comms=nx.community.louvain_communities(G,weight='weight',seed=seed,resolution=1.0)
    else: comms=nx.community.greedy_modularity_communities(G,weight='weight')
    mem={n:i for i,c in enumerate(sorted(comms,key=lambda c:-sum(cnt[x] for x in c))) for n in c}
    Q=nx.community.modularity(G,comms,weight='weight')
    return G,mem,Q,cnt
def compare(m1,m2):
    common=sorted(set(m1)&set(m2))
    if len(common)<5: return len(common),np.nan
    return len(common), nmi([m1[c] for c in common],[m2[c] for c in common])
