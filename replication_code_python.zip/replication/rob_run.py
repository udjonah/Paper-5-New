exec(open('load.py').read())
from net import *
import pickle
d=M[M.Year>=2021]
G,base,Q,cnt=cocit(d.refs.tolist(),60)
rows=[]
def add(name,mem):
    n,v=compare(base,mem); rows.append((name,'co-citation 2021-25',n,round(v,3)))
add('Top 90 references (+50%)',cocit(d.refs.tolist(),90)[1])
add('Top 30 references (-50%)',cocit(d.refs.tolist(),30)[1])
add('Salton normalisation',cocit(d.refs.tolist(),60,norm='salton')[1])
add('Greedy modularity clustering',cocit(d.refs.tolist(),60,algo='greedy')[1])
add('Louvain, different seed',cocit(d.refs.tolist(),60,seed=99)[1])
add('Reviews excluded',cocit(d[d['Document Type']!='Review'].refs.tolist(),60)[1])
add('Articles in press excluded',cocit(d[d['Publication Stage']=='Final'].refs.tolist(),60)[1])
# phase 1
d1=M[M.Year<2012]; G1,b1,Q1,_=cocit(d1.refs.tolist(),60)
for name,mem in [('Top 90 references (+50%)',cocit(d1.refs.tolist(),90)[1]),('Salton normalisation',cocit(d1.refs.tolist(),60,norm='salton')[1]),('Greedy modularity clustering',cocit(d1.refs.tolist(),60,algo='greedy')[1])]:
    n,v=compare(b1,mem); rows.append((name,'co-citation 1989-2011',n,round(v,3)))
R=pd.DataFrame(rows,columns=['check','analysis','shared_nodes','NMI']); print(R.to_string())
R.to_csv('robust.csv',index=False)
