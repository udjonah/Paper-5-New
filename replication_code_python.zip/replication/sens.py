exec(open('load.py').read())
from bp import *
from net import *
from collections import Counter
firm=r'\b(?:sme|smes|msme|msmes|small business\w*|small firm\w*|small and medium|micro[- ]?enterprise\w*|entrepreneur\w*|firm|firms|enterprise|enterprises|start-?ups?|self-employ\w*|business owner\w*|borrower\w*|compan(?:y|ies)|corporate)\b'
tk=(M.Title.fillna('')+' | '+M['Author Keywords'].fillna('')).str.lower()
M['firm']=tk.str.contains(firm)
S=M[M.firm].copy(); print('subset',len(S), S.community.value_counts().to_dict())
cuts=[1989,2012,2017,2021,2026]
for a,b in zip(cuts[:-1],cuts[1:]):
    d=S[(S.Year>=a)&(S.Year<b)]; v=d.community.value_counts(normalize=True)*100
    print(a,b-1,len(d),{k:round(v.get(k,0),1) for k in ['A','A&B','B']})
ann=S.groupby(['Year','community']).size().unstack(fill_value=0).reindex(range(1989,2026),fill_value=0)
ann['total']=ann.sum(axis=1)
yrs=ann.index.values; m=yrs>=2000
share=((ann.B+ann['A&B'])/ann.total.replace(0,np.nan)).fillna(0).values[m]
best,o=bai_perron(share,trend=False)
print('breaks',[(d['m'],round(d['bic'],1),[int(yrs[m][x]) for x in d['breaks']]) for d in o[:5]])
# CCI with full-sample exclusive cores
cA=Counter(k for r in M[M.community=='A'].refs for k in r); cB=Counter(k for r in M[M.community=='B'].refs for k in r)
a={k for k,_ in cA.most_common(100)}; b={k for k,_ in cB.most_common(100)}; ea,eb=a-b,b-a
S['xB']=S.refs.apply(lambda r: np.mean([k in eb for k in r]) if r else np.nan)
S['xA']=S.refs.apply(lambda r: np.mean([k in ea for k in r]) if r else np.nan)
for a_,b_ in zip(cuts[:-1],cuts[1:]):
    d=S[(S.Year>=a_)&(S.Year<b_)]
    print(a_,'A->B',round(100*d.loc[d.community=='A','xB'].mean(),2),'B->A',round(100*d.loc[d.community=='B','xA'].mean(),2))
# cocit phase 4 compare
d4=M[M.Year>=2021]; _,base,_,_=cocit(d4.refs.tolist(),60)
_,alt,Q,_=cocit(S[S.Year>=2021].refs.tolist(),60)
print('cocit p4 NMI',compare(base,alt),'Q',round(Q,3))
