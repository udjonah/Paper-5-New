exec(open('load.py').read())
import pickle
cm=pickle.load(open('coup_mem.pkl','rb'))
M['front']=[cm.get(i,-1) for i in M.index]
M['txt']=(M.Title.fillna('')+' '+M.Abstract.fillna('').str.replace(r'©.*$','',regex=True)+' '+M['Author Keywords'].fillna('')).str.lower()
D={
'T: information asymmetry':r'asymmetric information|information asymmetr|adverse selection|moral hazard|credit rationing|signal(l)?ing',
'T: transaction cost / lending technology':r'transaction cost|lending technolog|soft information|hard information|relationship lending',
'T: institutional theory':r'institutional theory|institutional quality|institutions\b|legal rights|creditor rights|credit information|credit bureau|credit registr',
'T: resource-based / capability':r'resource-based|resource based|\brbv\b|dynamic capabilit|capability approach|capabilities',
'T: technology adoption (TAM/UTAUT/TPB)':r'technology acceptance|\btam\b|utaut|planned behavio|diffusion of innovation',
'T: pecking order / capital structure':r'pecking order|capital structure|trade-off theory',
'T: discouraged borrowers':r'discourag',
'C: China':r'china|chinese',
'C: Sub-Saharan Africa':r'africa|nigeria|ghana|kenya|uganda|tanzania|ethiopia|rwanda|zambia|cameroon',
'C: South/Southeast Asia':r'india|pakistan|bangladesh|indonesia|vietnam|malaysia|philippines|sri lanka|nepal|thailand',
'C: Europe/US/UK':r'europe|united states|\bu\.s\.|\busa\b|united kingdom|\buk\b|germany|italy|spain|france',
'C: Latin America/MENA':r'latin america|brazil|mexico|peru|colombia|chile|middle east|mena|egypt|turkey|jordan|saudi',
'Ch: gender/women':r'women|female|gender',
'Ch: informal firms':r'informal',
'Ch: firm age/young firms':r'young firm|firm age|start-?up',
'Ch: rural/agricultural':r'rural|farmer|agricultur',
'M: survey':r'survey|questionnaire',
'M: SEM/PLS':r'structural equation|pls-sem|\bsem\b|smart-?pls|partial least',
'M: panel econometrics':r'panel data|fixed effect|\bgmm\b|panel regression',
'M: causal identification (DiD/IV/RDD/experiment)':r'difference-in-difference|difference in difference|\bdid\b|instrumental variable|\biv\b|regression discontinuity|randomi[sz]ed|natural experiment|quasi-experiment',
'M: probit/logit':r'probit|logit',
'M: qualitative/case':r'qualitative|case study|interview',
'M: review/bibliometric':r'systematic (literature )?review|bibliometric|meta-analys',
'D: access':r'access to (finance|credit|financ)|credit access|financing constraint|credit constraint|loan approval|rationed',
'D: usage':r'usage|use of (financial|digital|mobile)|adoption|uptake',
'D: quality (terms)':r'collateral|interest rate|loan terms|maturity|cost of (credit|capital|debt)|loan pricing|processing time|loan size',
'D: outcomes':r'growth|performance|innovation|productivity|resilience|investment|employment|survival|sustainab',
}
for k,p in D.items(): M[k]=M.txt.str.contains(p,regex=True)
F=M[M.front.isin(range(5))]
names={0:'F1',1:'F2',2:'F3',3:'F4',4:'F5'}
tab=(F.groupby('front')[list(D)].mean()*100).round(1).T; tab.columns=[names[c] for c in tab.columns]
tab['All fronts']=(F[list(D)].mean()*100).round(1)
tab['All corpus']=(M[list(D)].mean()*100).round(1)
print(tab.to_string()); print(len(F))
tab.to_csv('tccm.csv')
# by community
print((M.groupby('community')[list(D)].mean()*100).round(1).T.to_string())
# P6: gender & quality co-occurrence; P1: digital & collateral
dig=M.txt.str.contains(r'fintech|digital|mobile money|platform')
print('digital papers',dig.sum(),'with quality terms %',round(100*M.loc[dig,'D: quality (terms)'].mean(),1),'nondigital',round(100*M.loc[~dig,'D: quality (terms)'].mean(),1))
g=M['Ch: gender/women']
print('gender papers',g.sum(),'quality %',round(100*M.loc[g,'D: quality (terms)'].mean(),1),'access %',round(100*M.loc[g,'D: access'].mean(),1))
inst=M['T: institutional theory']; print('digital & institutional', (dig&inst).sum(), round(100*(dig&inst).sum()/dig.sum(),1))
print('digital & info asym',(dig&M['T: information asymmetry']).sum(), round(100*(dig&M['T: information asymmetry']).mean()*len(M)/dig.sum(),1))
cap=M.txt.str.contains(r'financial literacy|digital literacy|capabilit')
print('capability papers',cap.sum(),'with outcomes %', round(100*M.loc[cap,'D: outcomes'].mean(),1))
disc=M['T: discouraged borrowers']; print('discouragement papers',disc.sum(), M.loc[disc,'community'].value_counts().to_dict(), 'digital&disc',(dig&disc).sum())
# time trend of quality share
for a,b in [(1989,2011),(2012,2016),(2017,2020),(2021,2025)]:
    d=M[(M.Year>=a)&(M.Year<=b)]; print(a,b,'quality %',round(100*d['D: quality (terms)'].mean(),1),'access %',round(100*d['D: access'].mean(),1),'causal %',round(100*d['M: causal identification (DiD/IV/RDD/experiment)'].mean(),1))
