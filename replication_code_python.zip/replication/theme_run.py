exec(open('load.py').read())
import networkx as nx, itertools, json
from collections import Counter
SYN={'sme':'smes','small and medium enterprises':'smes','small and medium-sized enterprises':'smes','small and medium-sized enterprises (smes)':'smes','small and medium enterprises (smes)':'smes','smes':'smes','small business':'small businesses','small firms':'small businesses','small business finance':'small business finance',
'msme':'msmes','micro, small and medium enterprises':'msmes','msmes':'msmes','fintech':'fintech','financial technology':'fintech','financial technology (fintech)':'fintech',
'digital inclusive finance':'digital financial inclusion','digital financial inclusion':'digital financial inclusion','access to credit':'access to finance','credit access':'access to finance','access to financing':'access to finance','financial access':'access to finance',
'financing constraint':'financing constraints','financial constraints':'financing constraints','credit constraints':'credit constraints','credit constraint':'credit constraints','entrepreneurs':'entrepreneurship','women entrepreneurs':'women entrepreneurship','female entrepreneurship':'women entrepreneurship','mobile banking':'mobile money','banks':'banking','bank':'banking','covid-19 pandemic':'covid-19','covid 19':'covid-19','gender gap':'gender','microcredit':'microfinance','discouraged borrowers':'borrower discouragement','discouragement':'borrower discouragement','relationship banking':'relationship lending'}
def kws(s):
    out=[]
    for k in str(s).split(';'):
        k=k.strip().lower()
        if not k or k=='nan': continue
        out.append(SYN.get(k,k))
    return list(dict.fromkeys(out))
M['kw']=M['Author Keywords'].apply(kws)
CUTS=[(1989,2011),(2012,2016),(2017,2020),(2021,2025)]
def thematic(d,n=250,minfreq=3,seed=7):
    cnt=Counter(k for r in d.kw for k in r)
    keep=[k for k,v in cnt.most_common(n) if v>=minfreq]; ks=set(keep)
    co=Counter()
    for r in d.kw:
        for a,b in itertools.combinations(sorted(set(r)&ks),2): co[(a,b)]+=1
    G=nx.Graph(); G.add_nodes_from(keep)
    for (a,b),c in co.items(): G.add_edge(a,b,weight=c*c/(cnt[a]*cnt[b]),raw=c)
    G.remove_nodes_from([x for x in list(G) if G.degree(x)==0])
    comms=nx.community.louvain_communities(G,weight='weight',seed=seed)
    rows=[]
    for c in comms:
        if len(c)<3: continue
        c=set(c)
        internal=sum(G[a][b]['weight'] for a,b in G.subgraph(c).edges)
        external=sum(G[a][b]['weight'] for a in c for b in G[a] if b not in c)
        name=sorted(c,key=lambda k:-cnt[k])
        rows.append(dict(label=name[0],words=name[:8],size=len(c),freq=sum(cnt[k] for k in c),centrality=10*external,density=100*internal/len(c),members=sorted(c)))
    T=pd.DataFrame(rows)
    cm,dm=T.centrality.median(),T.density.median()
    T['quadrant']=np.select([(T.centrality>=cm)&(T.density>=dm),(T.centrality<cm)&(T.density>=dm),(T.centrality<cm)&(T.density<dm)],['Motor','Niche','Emerging or declining'],'Basic')
    return T.sort_values('freq',ascending=False),cnt
res={}
for i,(a,b) in enumerate(CUTS,1):
    d=M[(M.Year>=a)&(M.Year<=b)]
    T,cnt=thematic(d, minfreq=2 if i==1 else 3)
    res[i]=T
    print(f'=== Phase {i} {a}-{b}: docs with kw {(d.kw.str.len()>0).sum()}/{len(d)}; themes {len(T)}')
    for _,r in T.head(10).iterrows(): print(f"  {r.quadrant:22s} f={r.freq:4d} c={r.centrality:6.1f} d={r.density:6.1f} | {', '.join(r.words[:6])}")
    T.drop(columns=['members']).to_csv(f'theme_p{i}.csv',index=False)
# evolution: inclusion index between consecutive phases
print('\n=== EVOLUTION (inclusion index >= 0.15, weighted by shared words)')
ev=[]
for i in [1,2,3]:
    for _,x in res[i].iterrows():
        for _,y in res[i+1].iterrows():
            sh=set(x.members)&set(y.members)
            if sh:
                inc=len(sh)/min(len(x.members),len(y.members))
                if inc>=0.15: ev.append((i,x.label,i+1,y.label,round(inc,2),len(sh)))
for e in ev: print(e)
pd.DataFrame(ev,columns=['from_phase','from','to_phase','to','inclusion','shared']).to_csv('evolution.csv',index=False)
import pickle; pickle.dump({i:res[i] for i in res},open('themes.pkl','wb'))
M[['EID','kw']].to_pickle('kw.pkl')
